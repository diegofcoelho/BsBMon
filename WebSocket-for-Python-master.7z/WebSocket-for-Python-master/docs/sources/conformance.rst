.. _conformance:

Conformance
===========


ws4py tries hard to be as conformant as it can to the specification. 
In order to validate this conformance, each release is run against the 
`Autobahn testsuite <http://autobahn.ws/>`_ which provides an extensive 
coverage of various aspects of the protocol.

Online test reports can be found at: http://www.defuze.org/oss/ws4py/testreports/servers/
