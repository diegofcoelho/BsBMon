# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1463792238.6630917
_enable_loop = True
_template_filename = 'C:/Users/dfcoelho/Downloads/WebSocket-for-Python-master/example/websensors/templates/index.html'
_template_uri = 'index.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        baseurl = context.get('baseurl', UNDEFINED)
        boardid = context.get('boardid', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n    <head>\n        <meta charset="utf-8">\n        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">\n        <title>Shared drawing board</title>\n        <meta name="description" content="Remote control your webapp with your mobile device">\n        <meta name="viewport" content="width=device-width, initial-scale=1">\n        <meta name="twitter:card" content="Sylvain Hellegouarch\'s twitter account">\n        <meta name="twitter:site" content="@lawouach">\n        <meta name="twitter:url" content="http://www.defuze.org">\n\n        <link rel="stylesheet" href="/static/demos/drawing/vendors/initializr/css/normalize.min.css">\n        <link rel="stylesheet" href="/static/demos/drawing/vendors/initializr/css/main.min.css">\n\n        <script src="/static/demos/drawing/vendors/initializr/js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>\n    </head>\n    <body>\n        <!--[if lt IE 7]>\n            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n        <![endif]-->\n\n        <div class="header-container">\n            <header class="wrapper clearfix">\n                <h1 class="title">shared drawing board</h1>\n            </header>\n        </div>\n\n        <div class="main-container">\n            <div class="main wrapper clearfix">\n\n                <article>\n                    <section>\n                        <h2>what\'s this?</h2>\n\t                <p>This demo will demonstrate a fun usage of <a href="http://www.websocket.org/">WebSocket<a/>\n\t                   and <a href="http://diveintohtml5.info/canvas.html">canvases</a>.\n\t                   The idea is that you will share a drawing board with other\n\t                   users or devices and each time someone will draw something onto\n\t                   the canvas, all other participants will see the drawing in near real-time\n\t                   on their side too.\n\t                </p>\n\t                <p>Please use the link below to share a drawing board:</p>\n\t                <p><a href="')
        __M_writer(str(baseurl))
        __M_writer('/board/')
        __M_writer(str(boardid))
        __M_writer('">')
        __M_writer(str(baseurl))
        __M_writer('/board/')
        __M_writer(str(boardid))
        __M_writer('</a></p>\n\t                <p>Note that each board can last only 5mn as this for demoing purpose.</p>\n                    </section>\n                    <section>\n                        <h2>how does it work?</h2>\n\t                <p>The link above leads you to a page which will simply display\n\t                   two HTML5 canvases. One on the left acting as a simple toolbar\n\t                   to change your brush color and clear the whole drawing board. The\n\t                   canvas on the right is the drawing board where you can draw circles\n\t                   by clicking on your left button (or your finger on a mobile device).</p>\n\t                <p>In addition, in the background, a websocket connection is initialized\n\t                   with the server. That connection will be used to broadcast any drawing\n\t                   action you perform on your board.</p>\n\t                <p>Any other connected participant will then "see" whatever you draw on your\n\t                   board. Conversely, you will see what they draw as well.</p>\n\t                <p>The demo is hosted on a <a href="https://www.webfaction.com">WebFaction</a>\n\t                   shared host behind a Custom (websocket)\n\t                   application. This kind of application sets up a nginx frontend with the\n\t                   websocket module enabled. The demo simply runs a Python application listening\n                           on that port.</p>\n                        <p>Note that on your mobile, the <a href="http://www.html5rocks.com/en/tutorials/device/orientation/">device motion</a>\n                           is used whenever available. Press on the screen once and this ought\n                           to start the motion support. You will have to press again to stop it (or\n                           click on the Clean button).</p>\n\t             </section>\n                    <section>\n                        <h2>where does it work?</h2>\n                        <p>This demo relies on modern browsers support for HTML5 features such as\n                           <a href="http://caniuse.com/websockets">websocket</a> and\n                           <a href="http://caniuse.com/canvas">canvas</a>.</p>\n                        <p>It has been tested successfully on:</p>\n                        <ul>\n\t\t\t  <li>Chromium 33.0.1750.152</li>\n\t\t\t  <li>Firefox 28</li>\n\t\t\t  <li>Chrome 34.0.1847.114 on Android 4.2.2</li>\n\t\t\t  <li>Opera 12</li>\n\t\t\t  <li>Internet Explorer 11</li>\n\t\t\t</ul>\n\t\t\t<p>Note that the demo only supports <a href="https://tools.ietf.org/html/rfc6455">RFC 6455</a> which is the\n\t\t\t   official version of the WebSocket protocol. Some older devices\n\t\t\t   implement other draft versions that this demo does not speak.</a>\n                    <section>\n                        <h2>what tools are used for this demo?</h2>\n\t                <p>This demo uses the following libraries and tools:</p>\n\t                <ul>\n\t\t\t  <li><a href="http://www.cherrypy.org">CherryPy</a> as the application server running on Python</li>\n\t\t\t  <li><a href="https://github.com/Lawouach/WebSocket-for-Python">ws4py</a> as the websocket server endpoint</li>\n\t\t\t  <li><a href="https://pypi.python.org/pypi/wsaccel">wsaccel</a> which uses Cython to improve key parts of ws4py</li>\n\t\t\t  <li><a href="http://calebevans.me/projects/jcanvas/">jcanvas</a> for canvas manipulation and rendering</li>\n\t\t\t  <li><a href="http://www.initializr.com/">Initializr</a> for the HTML5 web page that you see</li>\n\t\t\t</ul>\n\t                <p>The source code of this demo can be found <a href="https://github.com/Lawouach/WebSocket-for-Python/tree/master/example/websensors">here</a>\n\t\t\t   as part of the ws4py package.</p>\n\t\t    </section>\n                </article>\n\n            </div> <!-- #main -->\n        </div> <!-- #main-container -->\n\n        <div class="footer-container">\n            <footer class="wrapper">\n                <p>&copy; 2014 | <a href="http://www.defuze.org/">Sylvain Hellegouarch</a></p>\n            </footer>\n        </div>\n\n        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>\n    </body>\n</html>\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "C:/Users/dfcoelho/Downloads/WebSocket-for-Python-master/example/websensors/templates/index.html", "source_encoding": "utf-8", "line_map": {"16": 0, "37": 31, "23": 1, "24": 46, "25": 46, "26": 46, "27": 46, "28": 46, "29": 46, "30": 46, "31": 46}, "uri": "index.html"}
__M_END_METADATA
"""
