# [Dashing](http://shopify.github.com/dashing)
[![Build Status](https://secure.travis-ci.org/Shopify/dashing.png?branch=master)](http://travis-ci.org/Shopify/dashing)

Dashing is a Sinatra based framework that lets you build beautiful dashboards. It looks especially great on TVs.

[Check out the homepage](http://shopify.github.com/dashing).

Note: Dashing is no longer being actively maintained. Read about it [here](https://github.com/Shopify/dashing/issues/711).

# License
Distributed under the [MIT license](MIT-LICENSE)
