from . import datamaps

Datamap = datamaps.Datamap
DatamapUSA = datamaps.DatamapUSA