# Code of Conduct

We are committed to keeping our community open and inclusive.

**Our Code of Conduct can be found here**:
http://opensource.stitchfix.com/code-of-conduct.html
