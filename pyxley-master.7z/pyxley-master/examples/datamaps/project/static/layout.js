
    import React from 'react';
    import ReactDOM from 'react-dom';
    import { FilterChart as Component} from 'pyxley';
    var filters = [{"options": {"max": 13, "default": "1", "label": "Month", "step": 1, "min": 1, "alias": "month"}, "type": "SliderInput"}];
var filter_style = "''";
var dynamic = true;
var charts = [{"options": {"chartid": "mapid", "params": {"month": "1"}, "url": "/data_map/"}, "type": "Datamaps"}];
    ReactDOM.render(
        <Component
        filters = { filters }
filter_style = { filter_style }
dynamic = { dynamic }
charts = { charts } />,
        document.getElementById("component_id")
    );
    