# Plot.ly example

# How to Install
Make sure pyxley is installed first (run `python setup.py install`).

## NPM
Install NPM (e.g brew install node).

## Initialize
Initialize the directory with `pyxapp --init .`.

# Flask
Run `python demo/__init__.py`.
