from . import datatable

DataTable = datatable.DataTable